$(function() {
    var isLogin = Cookie.has("user");
    if (!isLogin) { //判断当前用户是否已经登录
        //没有登录
        $("#login").show();
        $("#login > button").click(function() {
            var username = $("#login input:first").val();
            var pwd = $("#login input:eq(1)").val();
            $.ajax({
                url: "php/user.php",
                data: {
                    type: "login",
                    username: username,
                    password: pwd
                },
                success: function(res) {
                    res = $.parseJSON(res);
                    if (res.status == 0) {
                        $("#login").hide();
                        Cookie.setCookie("user", username);
                    }
                }
            })
        })
    } else {
        //已经登录 直接显示所有商品
        showItems();
    }
})
var currentPage = 1;
var pageSize = 5;

function showItems() {
    $.ajax({
        url: "php/items.php",
        data: {
            currentPage: currentPage, //当前页数
            pageSize: pageSize, //每页的条数
            orderBy: "all", //排序规则
            searchKey: "all" //搜索关键字
        },
        success: function(res) {
            res = $.parseJSON(res);
            var total = res.total; //获取返回结果中的总数 用于分页
            var data = res.data; //获取返回结果
            if (data.length > 0) {
                $(".itemsContainer").empty();
                for (var i = 0; i < data.length; i++) {
                    var obj = data[i];
                    createItemDom(obj);
                }
                // $(".pages").empty(); //性能优化
                if ($(".pages").children().length == 0) {
                    createPageDom(total); //调用创建分页按钮的方法
                }

            }
            // {
            //     total: 100,
            //     data:[{
            //         id:,
            //         name:
            //     }]
            // }
        }
    })
}

function createItemDom(obj) {

    // <div class="items">
    //         <p>商品名称</p>
    //         <p>单价</p>
    //         <input type="text" name="" value="0" placeholder="">
    //         <button type="">添加到购物车</button>
    //     </div>
    var btn = $("<button/>").html("添加到购物车");
    var div = $("<div class='items' />").attr("itemID", obj.id);
    div.append(
        $("<p/>").html(obj.name)
    ).append(
        $("<p/>").html(obj.price)
    ).append(
        $("<input type='text' value='0'/>")
    ).append(
        btn
    );
    $(".itemsContainer").append(div);
    btn.click(function() {
        var count = $(this).prev("input").val(); //得到当前点击按钮所在商品的选择数量
        // var itemID = obj.id; //取得当前商品的ID
        // alert(itemID)
        var itemID = $(this).parent().attr("itemid");
        console.log(count, itemID)
    })
}

function createPageDom(total) {
    var ul = $("<ul/>");
    var prevLi = $("<li/>").html("上一页").appendTo(ul);
    var nextLi = $("<li/>").html("下一页");
    var pageNum = Math.ceil(total / pageSize); //使用总条数/每页条数 得到分页数
    for (var i = 0; i < pageNum; i++) {
        var li = $("<li/>").html(i + 1);
        ul.append(li);
    }
    ul.append(nextLi);
    $(".pages").append(ul);
    ul.on("click", "li", function() {
        if ($(this).index() == 0) {
            currentPage -= 1;

        } else if ($(this).index() == pageNum + 1) {
            currentPage += 1;
        } else {
            currentPage = $(this).html();
        }
        showItems();
        $(".pages ul li").eq(currentPage).addClass("active").siblings("li").removeClass("active");
    })
    $(".pages ul li").eq(currentPage).addClass("active")
}
